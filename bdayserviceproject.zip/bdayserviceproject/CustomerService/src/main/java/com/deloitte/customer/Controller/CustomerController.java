package com.deloitte.customer.Controller;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.deloitte.customer.Entity.Customer;
import com.deloitte.customer.Model.User;
import com.deloitte.customer.Model.Response;
import com.deloitte.customer.Service.CustomerService;
import com.deloitte.customer.Service.CustomerServiceImpl;


@RestController
@RequestMapping("/customer")
public class CustomerController {

	
	@Autowired
	CustomerService customerService;
	
	@Autowired
	private RestTemplate restTemplate;
	
	@GetMapping("/getCustomers")
	public ResponseEntity<List<Customer>> getAllCustomers(){
		
    List<Customer> customers=customerService.getCustomers();
		return new ResponseEntity<List<Customer>>(customers,HttpStatus.OK);
	}
	
	@GetMapping("/getCustomer/{userId}")
	public ResponseEntity<?> getCustomerByBnakId(@PathVariable("userId") Integer userId) {
		
			Customer customer=(Customer) customerService.getCustomer(userId);
		List<User> customerList=restTemplate.getForObject("http://localhost:8087/orders/getOrder/"+userId,List.class);
		Response response=new Response(customer,customerList);
	
			return new ResponseEntity<Response>(response,HttpStatus.OK);
		}
}
