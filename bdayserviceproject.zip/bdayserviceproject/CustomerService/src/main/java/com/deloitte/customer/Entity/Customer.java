package com.deloitte.customer.Entity;

import jakarta.persistence.Column;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="Userinformation")
public class Customer {
	
	@Id
	  @GeneratedValue(strategy= GenerationType.AUTO)
	private  Integer userId;
	private String userName;
	private Integer itemNO;
	private Integer price;
	public Customer() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	public Customer(Integer userId, String userName, Integer itemNO, Integer price) {
		super();
		this.userId = userId;
		this.userName = userName;
		this.itemNO = itemNO;
		this.price = price;
	}


	public Integer getUserId() {
		return userId;
	}
	public void setUserId(Integer userId) {
		this.userId = userId;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public Integer getItemNO() {
		return itemNO;
	}
	public void setItemNO(Integer itemNO) {
		this.itemNO = itemNO;
	}
	public Integer getPrice() {
		return price;
	}
	public void setPrice(Integer price) {
		this.price = price;
	}
	
	
	
	


}





