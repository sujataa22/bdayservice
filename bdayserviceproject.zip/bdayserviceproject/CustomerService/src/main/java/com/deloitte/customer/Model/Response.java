package com.deloitte.customer.Model;

import java.util.List;


import com.deloitte.customer.Entity.Customer;

public class Response {

	private Customer customer;
	private List<User> User;
	public Customer getCustomer() {
		return customer;
	}
	public void setCustomer(Customer customer) {
		this.customer = customer;
	}
	public List<User> getUser() {
		return User;
	}
	public void setUser(List<User> User) {
		this.User = User;
	}
	public Response(Customer customer, List<User> User) {
		super();
		this.customer = customer;
		this.User = User;
	}
	public Response() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
}
