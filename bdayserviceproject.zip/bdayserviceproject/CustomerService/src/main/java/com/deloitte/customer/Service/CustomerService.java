package com.deloitte.customer.Service;

import java.util.List;


import com.deloitte.customer.Entity.Customer;



public interface CustomerService {

	public List<Customer> getCustomers();
	public List<Customer> getCustomer(Integer id);
}
